# RECALL Neural Core Dataset Package

Sanitized, read-only canonical export from RECALL SQLite (`mode=ro`) for Neural Core evaluation and training preparation.

## Contents
- `raw/memories.jsonl`: 80 non-deleted memories (active + archived), secrets and PII redacted.
- `raw/projects.json`: Project metadata.
- `raw/sessions.json`: Session metadata.
- `raw/lineage.json`: Memory lineage edges.
- `raw/custom_instructions.json`: Non-deleted custom instructions (active + inactive).
- `raw/extraction_report.json`: Phase 1 extraction counts and validation summary.
- `audit/corpus_audit.json`: Phase 2 classification, quality, conflict, suitability, and privacy audit.
- `manifest.json`: File inventory, SHA-256 checksums, and sanitization summary.
